# BoardPrep Final — Class 10

Major upgrades:
- 20 unique MCQs per subject in the built-in bank, randomly shuffled; 50-question attempts are assembled from the bank and options are shuffled.
- New Random 50 button.
- Chapter keyword notes and varied question bank retained.
- Mock Test tab linked to 3-hour Board Exam Mode.
- Analytics, XP, mistake notebook and focus timer retained.
- Official CBSE/NCERT/PYQ/sample-paper links retained.
- Mobile responsive and animated.
- Footer: Developed by Himanshu Kumar.

Important: The included MCQ bank is a starter question set. For a truly exhaustive 50+ unique questions per subject, expand the question bank with verified curriculum-aligned questions.
